import phantom.app as phantom
from phantom.base_connector import BaseConnector
from phantom.action_result import ActionResult
import requests

class OpenRouterConnector(BaseConnector):
    def __init__(self):
        super().__init__()
        self._api_key = None
        self._base_url = "https://openrouter.ai/api/v1"

    def initialize(self):
        config = self.get_config()
        self._api_key = config.get('api_key')
        if not self._api_key:
            self.save_progress("No API key found in asset configuration.")
        return phantom.APP_SUCCESS

    def handle_action(self, param):
        action = self.get_action_identifier()
        if action == "send_prompt":
            return self._handle_send_prompt(param)
        elif action == "stream_response":
            return self._handle_stream_response(param)
        elif action == "manage_api_keys":
            return self._handle_manage_api_keys(param)
        else:
            action_result = self.add_action_result(ActionResult(dict(param)))
            return action_result.set_status(phantom.APP_ERROR, f"Unknown action: {action}")

    def _handle_send_prompt(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        prompt = param.get("prompt")
        model = param.get("model")

        if not prompt or not model:
            return action_result.set_status(phantom.APP_ERROR, "Both 'prompt' and 'model' must be provided.")

        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}]
        }

        try:
            response = requests.post(
                f"{self._base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=30
            )
        except Exception as e:
            err = self._get_error_message_from_exception(e)
            return action_result.set_status(phantom.APP_ERROR, f"Request failed: {err}")

        if response.status_code != 200:
            return action_result.set_status(
                phantom.APP_ERROR,
                f"OpenRouter API returned HTTP {response.status_code}: {response.text}"
            )

        try:
            resp_json = response.json()
        except Exception as e:
            return action_result.set_status(phantom.APP_ERROR, f"Error parsing JSON: {str(e)}")

        action_result.add_data(resp_json)

        if "choices" in resp_json and len(resp_json["choices"]) > 0:
            content = resp_json["choices"][0].get("message", {}).get("content", "")
            action_result.update_summary({"assistant_reply": content})

        return action_result.set_status(phantom.APP_SUCCESS)

    def _handle_stream_response(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        return action_result.set_status(
            phantom.APP_ERROR,
            "Stream Response is not implemented. Use Send Prompt for synchronous call."
        )

    def _handle_manage_api_keys(self, param):
        action_result = self.add_action_result(ActionResult(dict(param)))
        if not self._api_key:
            return action_result.set_status(phantom.APP_ERROR, "No API key configured in the asset.")
        return action_result.set_status(phantom.APP_SUCCESS, "API key is configured and retrieved from Vault.")

    def finalize(self):
        return phantom.APP_SUCCESS

if __name__ == '__main__':
    import json, argparse
    argparser = argparse.ArgumentParser()
    argparser.add_argument("input_test_json", help="Input Test JSON file")
    argparser.add_argument("-p", "--password", help="password")
    args = argparser.parse_args()
    with open(args.input_test_json) as f:
        in_json = json.load(f)
    connector = OpenRouterConnector()
    connector._api_key = args.password
    ret_val = connector._handle_send_prompt(in_json.get('parameters', {}))
    print(f"Test result: {ret_val}")